package core;

import model.Message;
import model.TextMessage;
import shared.AbstractBinaryTree;
import shared.DataTransferSystem;

import java.util.*;

public class MessagingSystem implements DataTransferSystem {
    private Queue<Message> messages;
    private Message root;
    private int messagesSize;

    public MessagingSystem() {
        this.messages = new PriorityQueue<>();
        this.messagesSize = 0;
        this.root = null;
//        this.root = new BinaryTree<>();

    }

    @Override
    public void add(Message message) {
        Boolean contains = this.contains(message);

        this.messagesSize++;

        if (contains) {
            throw new IllegalArgumentException();
        }

        this.messages.add(message);

        if(this.root == null){
            this.root = message;
        }else{
            this.getByWeight(message.getParentId()).addChild(message);
        }


    }

    @Override
    public Message getByWeight(int weight) {
        for (Message message : messages) {
            if (message.getWeight() == weight) {
                return message;
            }
        }

        throw new IllegalArgumentException();
    }

    @Override
    public Message getLightest() {
        if (this.size() == 0) {
            throw new IllegalArgumentException();
        }

        return this.messages.peek();
    }

    // TODO
    @Override
    public Message getHeaviest() {
        if (this.size() == 0) {
            throw new IllegalArgumentException();
        }

        Queue<Message> tempMessages = new PriorityQueue<>(Comparator.comparingInt(Message::getWeight).reversed());

        tempMessages.addAll(this.messages);

        return tempMessages.peek();
    }

    @Override
    public Message deleteLightest() {
        if (this.size() == 0) {
            throw new IllegalArgumentException();
        }

        Message poll = this.messages.poll();
        this.messagesSize--;

        return poll;
    }

    @Override
    public Message deleteHeaviest() {
        if (this.size() == 0) {
            throw new IllegalArgumentException();
        }

        Queue<Message> tempMessages = new PriorityQueue<>(Comparator.comparingInt(Message::getWeight).reversed());

        tempMessages.addAll(this.messages);

        Message poll = tempMessages.poll();
        this.messagesSize--;

        return poll;
    }

    @Override
    public Boolean contains(Message message) {
        return this.messages.contains(message);
    }

    @Override
    public List<Message> getOrderedByWeight() {
        List<Message> messages = new ArrayList<>(this.messages);

        messages.sort(Comparator.comparingInt(Message::getWeight));

        return messages;
    }

    @Override
    public List<Message> getPostOrder() {
        List<Message> elements = new ArrayList<>(this.messages);
        List<Message> result = new ArrayList<>();

        postOrder(elements, result, 0);
        result.add(elements.get(0));

        return result;
    }

    private List<Message> postOrder(List<Message> elements, List<Message> result, int index) {
        int leftChildIndex = getLeftChildIndex(index);
        Message leftChild = this.getChild(leftChildIndex, elements);
        if(leftChild != null){
//            result.addAll(postOrder(elements, result, leftChildIndex));
            result.add(leftChild);
            postOrder(elements, result, leftChildIndex);
        }

        int rightChildIndex = getRightChildIndex(index);
        Message rightChild = this.getChild(rightChildIndex, elements);
        if(this.getChild(rightChildIndex, elements) != null){
            result.add(rightChild);
            postOrder(elements, result, rightChildIndex);
//            result.addAll(postOrder(elements, result, rightChildIndex));
        }

//        result.add(elements.get(0));

        return result;
    }

    @Override
    public List<Message> getPreOrder() {
        List<Message> elements = new ArrayList<>(this.messages);
        List<Message> result = new ArrayList<>();

        result.add(elements.get(0));
        preOrder(elements, result, 0);


        return result;
    }

    private List<Message> preOrder(List<Message> elements, List<Message> result, int index) {

//        result.add(elements.get(0));

        int leftChildIndex = getLeftChildIndex(index);
        if(this.getChild(leftChildIndex, elements) != null){
            result.addAll(preOrder(elements, result, leftChildIndex));
        }

        int rightChildIndex = getRightChildIndex(index);
        if(this.getChild(rightChildIndex, elements) != null){
            result.addAll(preOrder(elements, result, rightChildIndex));
        }

        return result;
    }


    @Override
    public List<Message> getInOrder() {
        List<Message> elements = new ArrayList<>(this.messages);
        List<Message> result = new ArrayList<>();

        inOrder(elements, result, 0);

        return result;
    }

    private List<Message> inOrder(List<Message> elements, List<Message> result, int index) {
        int leftChildIndex = getLeftChildIndex(index);
        if(this.getChild(leftChildIndex, elements) != null){
            result.addAll(inOrder(elements, result, leftChildIndex));
        }

        result.add(elements.get(0));

        int rightChildIndex = getRightChildIndex(index);
        if(this.getChild(rightChildIndex, elements) != null){
            result.addAll(inOrder(elements, result, rightChildIndex));
        }

        return result;
    }

    @Override
    public int size() {
        return this.messagesSize;
    }

    private int getParentIndexFor( int index) {
        return (index - 1) / 2;
    }

    private int getLeftChildIndex(int index) {
        return 2 * index + 1;
    }



    private int getRightChildIndex(int index) {
        return 2 * index + 2;
    }

    private Message getChild(int index, List<Message> elements) {
        if(index < 0 || index >= this.size()){
            return null;
        }
        return elements.get(index);
    }

//    private Message getRightChild(int index, List<Message> elements) {
//        return elements.get(index);
//    }
}
